#!/usr/bin/env python3
"""
Pneumonia Detection Inference Service
Loads and runs the fine-tuned Keras model for chest X-ray analysis
"""

import sys
import json
import base64
import io
import numpy as np
from pathlib import Path

try:
    import tensorflow as tf
    from tensorflow import keras
    from PIL import Image
except ImportError:
    print("Error: TensorFlow and required packages not installed", file=sys.stderr)
    sys.exit(1)


class PneumoniaDetectionModel:
    def __init__(self, model_path: str):
        """Initialize the model from a local path or URL"""
        self.model_path = model_path
        self.model = None
        self.input_size = 224
        self.class_names = ["NORMAL", "PNEUMONIA"]
        
    def load(self):
        """Load the Keras model"""
        try:
            print(f"Loading model from {self.model_path}", file=sys.stderr)
            self.model = keras.models.load_model(self.model_path)
            print("Model loaded successfully", file=sys.stderr)
            return True
        except Exception as e:
            print(f"Error loading model: {e}", file=sys.stderr)
            return False
    
    def preprocess_image(self, image_data: bytes) -> np.ndarray:
        """Preprocess image for model input"""
        try:
            # Load image from bytes
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to RGB if necessary
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Resize to model input size
            image = image.resize((self.input_size, self.input_size))
            
            # Convert to array and normalize
            image_array = np.array(image, dtype=np.float32)
            image_array = image_array / 255.0
            
            # Add batch dimension
            image_array = np.expand_dims(image_array, axis=0)
            
            return image_array
        except Exception as e:
            print(f"Error preprocessing image: {e}", file=sys.stderr)
            raise
    
    def predict(self, image_data: bytes) -> dict:
        """Run inference on image data"""
        if self.model is None:
            raise RuntimeError("Model not loaded")
        
        try:
            # Preprocess image
            image_array = self.preprocess_image(image_data)
            
            # Run inference
            predictions = self.model.predict(image_array, verbose=0)
            
            # Extract probabilities
            normal_prob = float(predictions[0][0]) * 100
            pneumonia_prob = float(predictions[0][1]) * 100
            
            # Determine prediction
            predicted_class_idx = np.argmax(predictions[0])
            predicted_class = self.class_names[predicted_class_idx]
            confidence = float(np.max(predictions[0])) * 100
            
            return {
                "prediction": predicted_class,
                "confidence": round(confidence, 2),
                "normal_probability": round(normal_prob, 2),
                "pneumonia_probability": round(pneumonia_prob, 2),
                "success": True
            }
        except Exception as e:
            print(f"Error during prediction: {e}", file=sys.stderr)
            return {
                "success": False,
                "error": str(e)
            }


def main():
    """Main entry point for inference service"""
    if len(sys.argv) < 2:
        print("Usage: python inference.py <model_path>", file=sys.stderr)
        sys.exit(1)
    
    model_path = sys.argv[1]
    
    # Initialize model
    detector = PneumoniaDetectionModel(model_path)
    if not detector.load():
        sys.exit(1)
    
    # Read image data from stdin (base64 encoded)
    try:
        input_data = sys.stdin.buffer.read()
        image_data = base64.b64decode(input_data)
        
        # Run inference
        result = detector.predict(image_data)
        
        # Output result as JSON
        print(json.dumps(result))
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": str(e)
        }))
        sys.exit(1)


if __name__ == "__main__":
    main()
