import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { 
  createScan, 
  getScansByUserId, 
  getScanById, 
  getScanCount,
  createModel,
  getActiveModel,
  getAllModels,
  getModelByVersion,
  setActiveModel,
  updateModel
} from "./db";
import { storagePut } from "./storage";
import { getAIService } from "./ai";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /**
   * Scans router - handles pneumonia detection analysis
   */
  scans: router({
    /**
     * Create a new scan from an uploaded image
     * Handles file upload to S3 and runs inference
     */
    create: protectedProcedure
      .input(z.object({
        imageBuffer: z.instanceof(Buffer),
        fileName: z.string(),
        fileFormat: z.enum(["JPEG", "PNG", "DICOM"]),
      }))
      .mutation(async ({ input, ctx }) => {
        try {
          // Upload image to S3
          const imageKey = `scans/${ctx.user.id}/${Date.now()}-${input.fileName}`;
          const { url: imageUrl } = await storagePut(imageKey, input.imageBuffer, "image/jpeg");

          // Get active model
          const activeModel = await getActiveModel();
          if (!activeModel) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "No active model available for inference",
            });
          }

          // Run inference
          const aiService = getAIService();
          const prediction = await aiService.predict(input.imageBuffer);

          // Create scan record
          const scan = await createScan({
            userId: ctx.user.id,
            imageKey,
            imageUrl,
            fileName: input.fileName,
            fileFormat: input.fileFormat,
            prediction: prediction.label,
            confidence: Math.round(prediction.confidence),
            normalProbability: Math.round(prediction.normalProbability),
            pneumoniaProbability: Math.round(prediction.pneumoniaProbability),
            processingTimeMs: prediction.processingTimeMs,
            modelVersion: activeModel.version,
          });

          if (!scan) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "Failed to save scan results",
            });
          }

          return scan;
        } catch (error) {
          console.error("[Scans] Create failed:", error);
          if (error instanceof TRPCError) throw error;
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: error instanceof Error ? error.message : "Failed to create scan",
          });
        }
      }),

    /**
     * Get a specific scan by ID
     */
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const scan = await getScanById(input.id);
        
        if (!scan) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Scan not found",
          });
        }

        // Verify ownership
        if (scan.userId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You do not have access to this scan",
          });
        }

        return scan;
      }),

    /**
     * Get scan history for the current user
     */
    list: protectedProcedure
      .input(z.object({
        limit: z.number().default(20),
        offset: z.number().default(0),
      }))
      .query(async ({ input, ctx }) => {
        const scans = await getScansByUserId(ctx.user.id, input.limit, input.offset);
        const total = await getScanCount(ctx.user.id);
        
        return {
          scans,
          total,
          limit: input.limit,
          offset: input.offset,
        };
      }),

    /**
     * Get total scan count for the current user
     */
    count: protectedProcedure.query(async ({ ctx }) => {
      return await getScanCount(ctx.user.id);
    }),
  }),

  /**
   * Models router - admin-only model management
   */
  models: router({
    /**
     * Get the currently active model
     */
    getActive: publicProcedure.query(async () => {
      return await getActiveModel();
    }),

    /**
     * Get all available models (admin only)
     */
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Only admins can view all models",
        });
      }
      return await getAllModels();
    }),

    /**
     * Create a new model (admin only)
     */
    create: protectedProcedure
      .input(z.object({
        version: z.string(),
        modelBuffer: z.instanceof(Buffer),
        architecture: z.string().optional(),
        trainingDataset: z.string().optional(),
        validationAccuracy: z.number().optional(),
        aucRoc: z.number().optional(),
        releaseNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Only admins can upload models",
          });
        }

        try {
          // Check if version already exists
          const existing = await getModelByVersion(input.version);
          if (existing) {
            throw new TRPCError({
              code: "CONFLICT",
              message: `Model version ${input.version} already exists`,
            });
          }

          // Upload model to S3
          const modelKey = `models/${input.version}/model.keras`;
          const { url: fileUrl } = await storagePut(modelKey, input.modelBuffer, "application/octet-stream");

          // Create model record
          const model = await createModel({
            version: input.version,
            fileKey: modelKey,
            fileUrl,
            fileSizeBytes: input.modelBuffer.length,
            architecture: input.architecture || "EfficientNetB0",
            trainingDataset: input.trainingDataset || "Guangzhou + RSNA",
            validationAccuracy: input.validationAccuracy,
            aucRoc: input.aucRoc,
            releaseNotes: input.releaseNotes,
            uploadedByUserId: ctx.user.id,
            isActive: 0,
          });

          if (!model) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "Failed to save model metadata",
            });
          }

          return model;
        } catch (error) {
          console.error("[Models] Create failed:", error);
          if (error instanceof TRPCError) throw error;
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: error instanceof Error ? error.message : "Failed to create model",
          });
        }
      }),

    /**
     * Set a model as active (admin only)
     */
    setActive: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Only admins can set active models",
          });
        }

        try {
          await setActiveModel(input.id);
          return await getActiveModel();
        } catch (error) {
          console.error("[Models] SetActive failed:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to set active model",
          });
        }
      }),

    /**
     * Update model metadata (admin only)
     */
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        validationAccuracy: z.number().optional(),
        aucRoc: z.number().optional(),
        releaseNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Only admins can update models",
          });
        }

        try {
          const { id, ...updates } = input;
          await updateModel(id, updates);
          return true;
        } catch (error) {
          console.error("[Models] Update failed:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update model",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
