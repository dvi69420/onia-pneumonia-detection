import { eq, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, scans, models, Scan, Model, InsertScan, InsertModel } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Scan queries
 */
export async function createScan(scan: InsertScan): Promise<Scan | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create scan: database not available");
    return null;
  }

  try {
    const result = await db.insert(scans).values(scan);
    const scanId = (result as any).insertId;
    return await getScanById(scanId);
  } catch (error) {
    console.error("[Database] Failed to create scan:", error);
    throw error;
  }
}

export async function getScanById(id: number): Promise<Scan | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get scan: database not available");
    return null;
  }

  const result = await db.select().from(scans).where(eq(scans.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getScansByUserId(
  userId: number,
  limit: number = 20,
  offset: number = 0
): Promise<Scan[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get scans: database not available");
    return [];
  }

  try {
    return await db
      .select()
      .from(scans)
      .where(eq(scans.userId, userId))
      .orderBy(desc(scans.createdAt))
      .limit(limit)
      .offset(offset);
  } catch (error) {
    console.error("[Database] Failed to get scans:", error);
    return [];
  }
}

export async function getScanCount(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot count scans: database not available");
    return 0;
  }

  try {
    const result = await db
      .select({ count: sql<number>`cast(count(*) as unsigned)` })
      .from(scans)
      .where(eq(scans.userId, userId));
    return result[0]?.count || 0;
  } catch (error) {
    console.error("[Database] Failed to count scans:", error);
    return 0;
  }
}

/**
 * Model queries
 */
export async function createModel(model: InsertModel): Promise<Model | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create model: database not available");
    return null;
  }

  try {
    const result = await db.insert(models).values(model);
    const modelId = (result as any).insertId;
    return await getModelById(modelId);
  } catch (error) {
    console.error("[Database] Failed to create model:", error);
    throw error;
  }
}

export async function getModelById(id: number): Promise<Model | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get model: database not available");
    return null;
  }

  const result = await db.select().from(models).where(eq(models.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getActiveModel(): Promise<Model | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get active model: database not available");
    return null;
  }

  try {
    const result = await db
      .select()
      .from(models)
      .where(eq(models.isActive, 1))
      .limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get active model:", error);
    return null;
  }
}

export async function getAllModels(): Promise<Model[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get models: database not available");
    return [];
  }

  try {
    return await db.select().from(models).orderBy(desc(models.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get models:", error);
    return [];
  }
}

export async function getModelByVersion(version: string): Promise<Model | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get model: database not available");
    return null;
  }

  try {
    const result = await db
      .select()
      .from(models)
      .where(eq(models.version, version))
      .limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get model by version:", error);
    return null;
  }
}

export async function setActiveModel(modelId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot set active model: database not available");
    return;
  }

  try {
    // Deactivate all models
    await db.update(models).set({ isActive: 0 });
    // Activate the specified model
    await db.update(models).set({ isActive: 1 }).where(eq(models.id, modelId));
  } catch (error) {
    console.error("[Database] Failed to set active model:", error);
    throw error;
  }
}

export async function updateModel(id: number, updates: Partial<Model>): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update model: database not available");
    return;
  }

  try {
    await db.update(models).set(updates).where(eq(models.id, id));
  } catch (error) {
    console.error("[Database] Failed to update model:", error);
    throw error;
  }
}
