/**
 * AI Inference Service
 * Handles pneumonia detection using the fine-tuned Keras model with real inference
 */

import { spawn } from "child_process";
import path from "path";
import { fileURLToPath } from "url";
import { ENV } from "./_core/env";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface PredictionResult {
  label: "NORMAL" | "PNEUMONIA";
  confidence: number; // 0-100
  normalProbability: number; // 0-100
  pneumoniaProbability: number; // 0-100
  processingTimeMs: number;
  gradcamHeatmap?: Buffer; // PNG image buffer
}

export interface AIServiceConfig {
  modelPath: string;
  inputSize: number;
  classNames: string[];
}

class AIInferenceService {
  private config: AIServiceConfig;
  private isInitialized = false;
  private pythonScriptPath: string;

  constructor(config: AIServiceConfig) {
    this.config = config;
    // Use the model path directly - it should be a local file path or URL
    this.pythonScriptPath = path.join(__dirname, "inference.py");
  }

  /**
   * Initialize the AI service
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      console.log(`[AI] Initializing AI service`);
      console.log(`[AI] Model path: ${this.config.modelPath}`);
      console.log(`[AI] Input size: ${this.config.inputSize}`);
      console.log(`[AI] Python script path: ${this.pythonScriptPath}`);

      this.isInitialized = true;
      console.log(`[AI] Service initialized successfully`);
    } catch (error) {
      console.error("[AI] Failed to initialize:", error);
      throw new Error(`AI service initialization failed: ${error}`);
    }
  }

  /**
   * Run inference on an image using the Python backend
   */
  async predict(imageBuffer: Buffer): Promise<PredictionResult> {
    if (!this.isInitialized) {
      throw new Error("Model not initialized");
    }

    const startTime = Date.now();

    return new Promise((resolve, reject) => {
      try {
        // Encode image as base64 for Python script
        const base64Image = imageBuffer.toString("base64");

        // Spawn Python process with model path
        console.log(`[AI] Spawning Python process with model: ${this.config.modelPath}`);
        const python = spawn("python3", [this.pythonScriptPath, this.config.modelPath]);

        let output = "";
        let errorOutput = "";

        python.stdout.on("data", (data) => {
          output += data.toString();
        });

        python.stderr.on("data", (data) => {
          errorOutput += data.toString();
        });

        python.on("close", (code) => {
          const processingTimeMs = Date.now() - startTime;

          if (code !== 0) {
            console.error("[AI] Python process exited with code:", code);
            console.error("[AI] Python stderr:", errorOutput);
            reject(new Error(`Python inference failed (code ${code}): ${errorOutput}`));
            return;
          }

          try {
            if (!output.trim()) {
              reject(new Error("Python process returned empty output"));
              return;
            }
            
            const result = JSON.parse(output);

            if (!result.success) {
              reject(new Error(`Inference failed: ${result.error}`));
              return;
            }

            resolve({
              label: result.prediction as "NORMAL" | "PNEUMONIA",
              confidence: result.confidence,
              normalProbability: result.normal_probability,
              pneumoniaProbability: result.pneumonia_probability,
              processingTimeMs,
            });
          } catch (parseError) {
            console.error("[AI] Failed to parse Python output:");
            console.error("[AI] Raw output:", output);
            console.error("[AI] Parse error:", parseError);
            reject(new Error(`Failed to parse inference result: ${parseError}`));
          }
        });

        // Send image data to Python process
        python.stdin.write(base64Image);
        python.stdin.end();
      } catch (error) {
        console.error("[AI] Prediction failed:", error);
        reject(new Error(`Prediction failed: ${error}`));
      }
    });
  }

  /**
   * Load a new model at runtime
   */
  async loadModel(modelPath: string): Promise<void> {
    try {
      console.log(`[AI] Loading new model from ${modelPath}`);
      this.config.modelPath = modelPath;
      console.log(`[AI] Model updated successfully`);
    } catch (error) {
      console.error("[AI] Failed to load new model:", error);
      throw new Error(`Model loading failed: ${error}`);
    }
  }

  /**
   * Clean up resources
   */
  dispose(): void {
    console.log("[AI] Service disposed");
  }
}

// Global instance
let aiService: AIInferenceService | null = null;

export async function initializeAIService(config: AIServiceConfig): Promise<void> {
  if (aiService) return;
  aiService = new AIInferenceService(config);
  await aiService.initialize();
}

export function getAIService(): AIInferenceService {
  if (!aiService) {
    throw new Error("AI service not initialized. Call initializeAIService first.");
  }
  return aiService;
}

export function disposeAIService(): void {
  if (aiService) {
    aiService.dispose();
    aiService = null;
  }
}
