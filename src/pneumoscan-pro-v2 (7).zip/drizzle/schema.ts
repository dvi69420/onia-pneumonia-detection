import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Pneumonia scan records - stores all uploaded scans and their AI predictions.
 * Each scan is associated with a user and includes the original image, prediction result,
 * confidence scores, and Grad-CAM visualization.
 */
export const scans = mysqlTable("scans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  /** Original image file key in S3 storage */
  imageKey: varchar("imageKey", { length: 255 }).notNull(),
  /** URL to access the original image */
  imageUrl: text("imageUrl").notNull(),
  /** Original filename uploaded by user */
  fileName: varchar("fileName", { length: 255 }).notNull(),
  /** File format: JPEG, PNG, or DICOM */
  fileFormat: varchar("fileFormat", { length: 20 }).notNull(),
  /** AI prediction result: NORMAL or PNEUMONIA */
  prediction: varchar("prediction", { length: 20 }).notNull(),
  /** Confidence score for the predicted class (0-100) */
  confidence: int("confidence").notNull(),
  /** Probability of NORMAL class (0-100) */
  normalProbability: int("normalProbability").notNull(),
  /** Probability of PNEUMONIA class (0-100) */
  pneumoniaProbability: int("pneumoniaProbability").notNull(),
  /** Grad-CAM heatmap visualization key in S3 */
  heatmapKey: varchar("heatmapKey", { length: 255 }),
  /** URL to access the Grad-CAM heatmap */
  heatmapUrl: text("heatmapUrl"),
  /** Processing time in milliseconds */
  processingTimeMs: int("processingTimeMs"),
  /** Model version used for this prediction */
  modelVersion: varchar("modelVersion", { length: 64 }).default("1.0").notNull(),
  /** Additional notes or metadata */
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Scan = typeof scans.$inferSelect;
export type InsertScan = typeof scans.$inferInsert;

/**
 * Model metadata - tracks deployed AI models for versioning and rollback.
 * Allows admins to upload and manage different model versions without redeployment.
 */
export const models = mysqlTable("models", {
  id: int("id").autoincrement().primaryKey(),
  /** Semantic version (e.g., 1.0.0, 1.1.0) */
  version: varchar("version", { length: 64 }).notNull().unique(),
  /** Model file key in S3 storage */
  fileKey: varchar("fileKey", { length: 255 }).notNull(),
  /** URL to access the model file */
  fileUrl: text("fileUrl").notNull(),
  /** File size in bytes */
  fileSizeBytes: int("fileSizeBytes"),
  /** Model architecture description (e.g., EfficientNetB0) */
  architecture: varchar("architecture", { length: 255 }).default("EfficientNetB0").notNull(),
  /** Training dataset info */
  trainingDataset: varchar("trainingDataset", { length: 255 }).default("Guangzhou + RSNA").notNull(),
  /** Validation accuracy (stored as percentage) */
  validationAccuracy: int("validationAccuracy"),
  /** AUC-ROC score (stored as percentage) */
  aucRoc: int("aucRoc"),
  /** Whether this model is currently active/deployed */
  isActive: int("isActive").default(0).notNull(),
  /** Release notes or changelog */
  releaseNotes: text("releaseNotes"),
  /** User who uploaded this model */
  uploadedByUserId: int("uploadedByUserId").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Model = typeof models.$inferSelect;
export type InsertModel = typeof models.$inferInsert;