/**
 * ConfidenceBar - Visual representation of model confidence score
 * Shows a horizontal bar with percentage and color coding
 */
interface ConfidenceBarProps {
  confidence: number; // 0-100
  label?: string;
  showPercentage?: boolean;
}

export function ConfidenceBar({
  confidence,
  label = "Model Confidence",
  showPercentage = true,
}: ConfidenceBarProps) {
  // Color coding: red (0-50%), yellow (50-80%), green (80-100%)
  let barColor = "bg-red-500";
  let textColor = "text-red-700";

  if (confidence >= 80) {
    barColor = "bg-emerald-500";
    textColor = "text-emerald-700";
  } else if (confidence >= 50) {
    barColor = "bg-yellow-500";
    textColor = "text-yellow-700";
  }

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        {showPercentage && (
          <span className={`text-sm font-semibold ${textColor}`}>
            {confidence.toFixed(1)}%
          </span>
        )}
      </div>
      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
        <div
          className={`h-full ${barColor} transition-all duration-500`}
          style={{ width: `${confidence}%` }}
        />
      </div>
    </div>
  );
}
