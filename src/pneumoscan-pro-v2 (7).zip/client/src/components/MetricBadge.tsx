import { Card } from "@/components/ui/card";
import { BarChart3 } from "lucide-react";

/**
 * MetricBadge - Displays a single model evaluation metric
 * Used for showing accuracy, AUC-ROC, and other performance indicators
 */
interface MetricBadgeProps {
  label: string;
  value: string | number;
  description?: string;
  icon?: React.ReactNode;
}

export function MetricBadge({
  label,
  value,
  description,
  icon = <BarChart3 className="h-5 w-5" />,
}: MetricBadgeProps) {
  return (
    <Card className="p-4 space-y-2 hover:shadow-md transition-shadow">
      <div className="flex items-center gap-2">
        <div className="text-blue-600">{icon}</div>
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      {description && (
        <p className="text-xs text-muted-foreground">{description}</p>
      )}
    </Card>
  );
}

/**
 * MetricsGrid - Displays multiple metrics in a responsive grid
 */
interface MetricsGridProps {
  metrics: MetricBadgeProps[];
}

export function MetricsGrid({ metrics }: MetricsGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
      {metrics.map((metric, idx) => (
        <MetricBadge key={idx} {...metric} />
      ))}
    </div>
  );
}
