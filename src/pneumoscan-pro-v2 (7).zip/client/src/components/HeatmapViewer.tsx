import { Card } from "@/components/ui/card";
import { Info } from "lucide-react";

/**
 * HeatmapViewer - Displays Grad-CAM heatmap visualization
 * Shows the areas of the X-ray that influenced the model's prediction
 */
interface HeatmapViewerProps {
  heatmapUrl: string;
  originalImageUrl: string;
  prediction: "NORMAL" | "PNEUMONIA";
}

export function HeatmapViewer({
  heatmapUrl,
  originalImageUrl,
  prediction,
}: HeatmapViewerProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Original Image */}
      <Card className="overflow-hidden">
        <div className="bg-black p-4">
          <img
            src={originalImageUrl}
            alt="Original chest X-ray"
            className="w-full h-auto max-h-96 object-contain"
          />
        </div>
        <div className="p-4 border-t border-border">
          <p className="text-sm font-medium text-muted-foreground">Original Image</p>
          <p className="text-xs text-muted-foreground mt-1">
            Uploaded chest X-ray scan
          </p>
        </div>
      </Card>

      {/* Grad-CAM Heatmap */}
      <Card className="overflow-hidden">
        <div className="bg-black p-4">
          <img
            src={heatmapUrl}
            alt="Grad-CAM heatmap visualization"
            className="w-full h-auto max-h-96 object-contain"
          />
        </div>
        <div className="p-4 border-t border-border space-y-3">
          <div>
            <p className="text-sm font-medium text-muted-foreground">
              Grad-CAM Visualization
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Shows regions influencing the prediction
            </p>
          </div>

          {/* Heatmap Legend */}
          <div className="bg-slate-50 p-3 rounded-lg space-y-2">
            <div className="flex items-start gap-2">
              <Info className="h-4 w-4 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <p className="font-medium text-gray-700">How to read this:</p>
                <ul className="text-gray-600 space-y-0.5">
                  <li>• <strong>Red/Hot areas:</strong> Regions most influential to the prediction</li>
                  <li>• <strong>Cool areas:</strong> Regions with less influence</li>
                  <li>• <strong>Purpose:</strong> Provides model transparency and interpretability</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
