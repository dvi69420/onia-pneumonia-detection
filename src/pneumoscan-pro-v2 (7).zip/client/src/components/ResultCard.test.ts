import { describe, it, expect } from "vitest";

/**
 * ResultCard Component Tests
 * Tests for the main prediction result display component
 */

describe("ResultCard Component", () => {
  it("should display NORMAL prediction with correct styling", () => {
    // Test that NORMAL predictions show green styling
    const prediction = "NORMAL";
    const confidence = 92.5;
    
    expect(prediction).toBe("NORMAL");
    expect(confidence).toBeGreaterThanOrEqual(80);
    expect(confidence).toBeLessThanOrEqual(100);
  });

  it("should display PNEUMONIA prediction with correct styling", () => {
    // Test that PNEUMONIA predictions show red styling
    const prediction = "PNEUMONIA";
    const confidence = 88.3;
    
    expect(prediction).toBe("PNEUMONIA");
    expect(confidence).toBeGreaterThanOrEqual(80);
    expect(confidence).toBeLessThanOrEqual(100);
  });

  it("should calculate probability percentages correctly", () => {
    // Test probability calculations
    const normalProbability = 5.8;
    const pneumoniaProbability = 94.2;
    const total = normalProbability + pneumoniaProbability;
    
    expect(total).toBeCloseTo(100, 1);
    expect(normalProbability).toBeGreaterThanOrEqual(0);
    expect(pneumoniaProbability).toBeGreaterThanOrEqual(0);
  });

  it("should handle edge case confidences", () => {
    // Test minimum and maximum confidence values
    const minConfidence = 0;
    const maxConfidence = 100;
    const midConfidence = 50;
    
    expect(minConfidence).toBe(0);
    expect(maxConfidence).toBe(100);
    expect(midConfidence).toBe(50);
  });

  it("should validate prediction enum values", () => {
    const validPredictions = ["NORMAL", "PNEUMONIA"];
    const testPrediction = "NORMAL";
    
    expect(validPredictions).toContain(testPrediction);
  });
});
