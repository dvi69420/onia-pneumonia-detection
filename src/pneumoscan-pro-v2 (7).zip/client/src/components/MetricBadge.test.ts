import { describe, it, expect } from "vitest";

/**
 * MetricBadge Component Tests
 * Tests for model performance metrics display
 */

describe("MetricBadge Component", () => {
  it("should display accuracy metric correctly", () => {
    const label = "Validation Accuracy";
    const value = "95%";
    const description = "On test dataset";
    
    expect(label).toBe("Validation Accuracy");
    expect(value).toBe("95%");
    expect(description).toBe("On test dataset");
  });

  it("should display AUC-ROC metric correctly", () => {
    const label = "AUC-ROC Score";
    const value = "0.98";
    const description = "Model discrimination";
    
    expect(label).toBe("AUC-ROC Score");
    expect(value).toBe("0.98");
    expect(description).toBe("Model discrimination");
  });

  it("should validate accuracy percentage", () => {
    const accuracy = 95;
    
    expect(accuracy).toBeGreaterThanOrEqual(0);
    expect(accuracy).toBeLessThanOrEqual(100);
  });

  it("should validate AUC-ROC score range", () => {
    const aucRoc = 0.98;
    
    expect(aucRoc).toBeGreaterThanOrEqual(0);
    expect(aucRoc).toBeLessThanOrEqual(1);
  });

  it("should display dataset information", () => {
    const label = "Training Dataset";
    const value = "2";
    const description = "Guangzhou + RSNA";
    
    expect(label).toBe("Training Dataset");
    expect(value).toBe("2");
    expect(description).toContain("Guangzhou");
    expect(description).toContain("RSNA");
  });

  it("should display model architecture", () => {
    const label = "Architecture";
    const value = "CNN";
    const description = "EfficientNetB0";
    
    expect(label).toBe("Architecture");
    expect(value).toBe("CNN");
    expect(description).toBe("EfficientNetB0");
  });

  it("should render metrics grid with multiple items", () => {
    const metrics = [
      { label: "Accuracy", value: "95%" },
      { label: "AUC-ROC", value: "0.98" },
      { label: "Datasets", value: "2" },
      { label: "Architecture", value: "CNN" },
    ];
    
    expect(metrics).toHaveLength(4);
    expect(metrics[0]?.label).toBe("Accuracy");
    expect(metrics[3]?.value).toBe("CNN");
  });
});
