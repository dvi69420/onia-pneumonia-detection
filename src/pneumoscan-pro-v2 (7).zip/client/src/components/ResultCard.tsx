import { AlertCircle, CheckCircle } from "lucide-react";
import { Card } from "@/components/ui/card";

interface ResultCardProps {
  prediction: "NORMAL" | "PNEUMONIA";
  confidence: number;
  normalProbability: number;
  pneumoniaProbability: number;
}

/**
 * ResultCard - Displays the AI prediction result with visual hierarchy
 * Shows prediction status, confidence score, and probability breakdown
 */
export function ResultCard({
  prediction,
  confidence,
  normalProbability,
  pneumoniaProbability,
}: ResultCardProps) {
  const isNormal = prediction === "NORMAL";
  const bgColor = isNormal ? "bg-emerald-50" : "bg-red-50";
  const borderColor = isNormal ? "border-emerald-200" : "border-red-200";
  const textColor = isNormal ? "text-emerald-900" : "text-red-900";
  const subtextColor = isNormal ? "text-emerald-800" : "text-red-800";

  return (
    <Card className={`${bgColor} ${borderColor} border-2 p-6 space-y-4`}>
      <div className="flex items-start gap-4">
        {isNormal ? (
          <CheckCircle className="h-8 w-8 text-emerald-600 flex-shrink-0" />
        ) : (
          <AlertCircle className="h-8 w-8 text-red-600 flex-shrink-0" />
        )}
        <div className="flex-1">
          <h2 className={`text-2xl font-semibold mb-2 ${textColor}`}>
            {isNormal ? "Normal" : "Pneumonia Detected"}
          </h2>
          <p className={`text-lg font-medium mb-6 ${subtextColor}`}>
            Confidence: {confidence.toFixed(1)}%
          </p>

          {/* Probability Bars */}
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium">Normal</span>
                <span className="font-semibold">{normalProbability.toFixed(1)}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-500"
                  style={{ width: `${normalProbability}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium">Pneumonia</span>
                <span className="font-semibold">{pneumoniaProbability.toFixed(1)}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-500 transition-all duration-500"
                  style={{ width: `${pneumoniaProbability}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
