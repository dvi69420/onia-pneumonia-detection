import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

/**
 * SampleImages - Quick-load sample chest X-ray images for testing
 */
interface SampleImage {
  id: string;
  name: string;
  description: string;
  url: string;
  category: "normal" | "pneumonia";
}

const sampleImages: SampleImage[] = [
  {
    id: "sample-normal-1",
    name: "Normal Chest X-Ray",
    description: "Healthy chest with no pneumonia indicators",
    url: "https://via.placeholder.com/400x400?text=Normal+X-Ray",
    category: "normal",
  },
  {
    id: "sample-pneumonia-1",
    name: "Pneumonia Case",
    description: "Chest X-ray showing pneumonia indicators",
    url: "https://via.placeholder.com/400x400?text=Pneumonia+X-Ray",
    category: "pneumonia",
  },
];

interface SampleImagesProps {
  onSelectImage: (imageUrl: string, imageName: string) => void;
}

export function SampleImages({ onSelectImage }: SampleImagesProps) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2">Sample Images</h3>
        <p className="text-sm text-gray-600">
          Try the analysis with these sample chest X-rays
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sampleImages.map((image) => (
          <Card
            key={image.id}
            className="overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="aspect-square bg-gray-200 overflow-hidden">
              <img
                src={image.url}
                alt={image.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4 space-y-3">
              <div>
                <p className="font-semibold text-sm">{image.name}</p>
                <p className="text-xs text-gray-600">{image.description}</p>
              </div>
              <div className="flex gap-2">
                <span
                  className={`px-2 py-1 rounded text-xs font-medium ${
                    image.category === "normal"
                      ? "bg-emerald-100 text-emerald-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {image.category === "normal" ? "Normal" : "Pneumonia"}
                </span>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="w-full gap-2"
                onClick={() => onSelectImage(image.url, image.name)}
              >
                <Download className="h-4 w-4" />
                Load Sample
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
