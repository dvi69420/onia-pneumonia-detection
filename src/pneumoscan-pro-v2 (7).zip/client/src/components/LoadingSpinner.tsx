import { Loader2 } from "lucide-react";

/**
 * LoadingSpinner - Animated loading indicator with optional message
 */
interface LoadingSpinnerProps {
  message?: string;
  size?: "sm" | "md" | "lg";
}

export function LoadingSpinner({ message, size = "md" }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: "h-6 w-6",
    md: "h-10 w-10",
    lg: "h-16 w-16",
  };

  return (
    <div className="flex flex-col items-center justify-center gap-3">
      <Loader2 className={`${sizeClasses[size]} animate-spin text-blue-600`} />
      {message && (
        <p className="text-sm text-gray-600 font-medium">{message}</p>
      )}
    </div>
  );
}

/**
 * ProgressSteps - Step-by-step progress indicator
 */
interface ProgressStep {
  label: string;
  status: "pending" | "in-progress" | "completed";
}

interface ProgressStepsProps {
  steps: ProgressStep[];
}

export function ProgressSteps({ steps }: ProgressStepsProps) {
  return (
    <div className="space-y-3">
      {steps.map((step, idx) => (
        <div key={idx} className="flex items-center gap-3">
          <div
            className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold ${
              step.status === "completed"
                ? "bg-emerald-500 text-white"
                : step.status === "in-progress"
                  ? "bg-blue-500 text-white"
                  : "bg-gray-200 text-gray-600"
            }`}
          >
            {step.status === "completed" ? "✓" : idx + 1}
          </div>
          <span
            className={`text-sm font-medium ${
              step.status === "completed"
                ? "text-emerald-600"
                : step.status === "in-progress"
                  ? "text-blue-600"
                  : "text-gray-600"
            }`}
          >
            {step.label}
          </span>
          {step.status === "in-progress" && (
            <Loader2 className="h-4 w-4 animate-spin text-blue-600 ml-auto" />
          )}
        </div>
      ))}
    </div>
  );
}
