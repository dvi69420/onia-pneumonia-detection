import { describe, it, expect } from "vitest";

/**
 * ConfidenceBar Component Tests
 * Tests for confidence score visualization
 */

describe("ConfidenceBar Component", () => {
  it("should classify confidence as low (0-50%)", () => {
    const confidence = 35;
    const isLow = confidence < 50;
    
    expect(isLow).toBe(true);
    expect(confidence).toBeGreaterThanOrEqual(0);
    expect(confidence).toBeLessThan(50);
  });

  it("should classify confidence as medium (50-80%)", () => {
    const confidence = 65;
    const isMedium = confidence >= 50 && confidence < 80;
    
    expect(isMedium).toBe(true);
  });

  it("should classify confidence as high (80-100%)", () => {
    const confidence = 92.5;
    const isHigh = confidence >= 80;
    
    expect(isHigh).toBe(true);
    expect(confidence).toBeLessThanOrEqual(100);
  });

  it("should handle boundary values correctly", () => {
    const boundaries = [0, 50, 80, 100];
    
    boundaries.forEach((value) => {
      expect(value).toBeGreaterThanOrEqual(0);
      expect(value).toBeLessThanOrEqual(100);
    });
  });

  it("should format confidence as percentage string", () => {
    const confidence = 94.2;
    const formatted = `${confidence.toFixed(1)}%`;
    
    expect(formatted).toBe("94.2%");
    expect(formatted).toMatch(/^\d+\.?\d*%$/);
  });

  it("should validate confidence range", () => {
    const validConfidences = [0, 25, 50, 75, 100];
    
    validConfidences.forEach((conf) => {
      expect(conf).toBeGreaterThanOrEqual(0);
      expect(conf).toBeLessThanOrEqual(100);
    });
  });
});
