import { AlertCircle, Shield } from "lucide-react";
import { Card } from "@/components/ui/card";

type DisclaimerType = "medical" | "ethical" | "limitations" | "warning";

interface DisclaimerBannerProps {
  type?: DisclaimerType;
  title?: string;
  content: string | React.ReactNode;
  showIcon?: boolean;
}

/**
 * DisclaimerBanner - Displays important disclaimers and warnings
 * Used for medical disclaimers, ethical notices, and model limitations
 */
export function DisclaimerBanner({
  type = "medical",
  title,
  content,
  showIcon = true,
}: DisclaimerBannerProps) {
  const typeConfig = {
    medical: {
      bgColor: "bg-amber-50",
      borderColor: "border-amber-200",
      textColor: "text-amber-900",
      subtextColor: "text-amber-800",
      iconColor: "text-amber-600",
      icon: <Shield className="h-6 w-6" />,
      defaultTitle: "Medical Disclaimer",
    },
    ethical: {
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      textColor: "text-blue-900",
      subtextColor: "text-blue-800",
      iconColor: "text-blue-600",
      icon: <AlertCircle className="h-6 w-6" />,
      defaultTitle: "Ethical Notice",
    },
    limitations: {
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
      textColor: "text-orange-900",
      subtextColor: "text-orange-800",
      iconColor: "text-orange-600",
      icon: <AlertCircle className="h-6 w-6" />,
      defaultTitle: "Model Limitations",
    },
    warning: {
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
      textColor: "text-red-900",
      subtextColor: "text-red-800",
      iconColor: "text-red-600",
      icon: <AlertCircle className="h-6 w-6" />,
      defaultTitle: "Important Warning",
    },
  };

  const config = typeConfig[type];
  const displayTitle = title || config.defaultTitle;

  return (
    <Card
      className={`${config.bgColor} ${config.borderColor} border-2 p-6 md:p-8 space-y-4`}
    >
      <div className="flex gap-4">
        {showIcon && (
          <div className={`${config.iconColor} flex-shrink-0 mt-0.5`}>
            {config.icon}
          </div>
        )}
        <div className="space-y-2 flex-1">
          <h3 className={`font-semibold ${config.textColor}`}>{displayTitle}</h3>
          <div className={`text-sm ${config.subtextColor}`}>
            {typeof content === "string" ? <p>{content}</p> : content}
          </div>
        </div>
      </div>
    </Card>
  );
}

/**
 * ModelLimitationsNotice - Specific disclaimer for model limitations
 */
export function ModelLimitationsNotice() {
  return (
    <DisclaimerBanner
      type="limitations"
      title="Model Limitations & Accuracy"
      content={
        <ul className="space-y-2 list-disc list-inside">
          <li>
            <strong>Not a medical diagnosis:</strong> This tool provides AI-assisted analysis only and cannot replace professional radiologist review.
          </li>
          <li>
            <strong>Validation accuracy:</strong> Model achieves 95% accuracy on test datasets (Guangzhou + RSNA).
          </li>
          <li>
            <strong>Possible errors:</strong> Like all AI models, false positives and false negatives can occur. Always seek professional medical consultation.
          </li>
          <li>
            <strong>Image quality matters:</strong> Poor quality or non-standard X-ray images may reduce accuracy.
          </li>
          <li>
            <strong>Clinical context:</strong> AI predictions should be combined with clinical examination and patient history.
          </li>
        </ul>
      }
    />
  );
}

/**
 * EthicalDisclaimerNotice - Specific disclaimer for ethical responsibility
 */
export function EthicalDisclaimerNotice() {
  return (
    <DisclaimerBanner
      type="ethical"
      title="Ethical Responsibility & Transparency"
      content={
        <div className="space-y-2">
          <p>
            <strong>Model Transparency:</strong> This application uses a CNN-based EfficientNetB0 model trained on publicly available chest X-ray datasets. Grad-CAM visualizations are provided to help understand model decisions.
          </p>
          <p>
            <strong>Data Privacy:</strong> All uploaded images are processed securely and stored in compliance with healthcare data protection standards.
          </p>
          <p>
            <strong>Bias Awareness:</strong> AI models can reflect biases in training data. Clinical judgment and human expertise remain essential for diagnosis.
          </p>
        </div>
      }
    />
  );
}
