import { describe, it, expect } from "vitest";

/**
 * DisclaimerBanner Component Tests
 * Tests for disclaimer and warning displays
 */

describe("DisclaimerBanner Component", () => {
  it("should have medical disclaimer type", () => {
    const type = "medical";
    const validTypes = ["medical", "ethical", "limitations", "warning"];
    
    expect(validTypes).toContain(type);
  });

  it("should have ethical disclaimer type", () => {
    const type = "ethical";
    const validTypes = ["medical", "ethical", "limitations", "warning"];
    
    expect(validTypes).toContain(type);
  });

  it("should have model limitations type", () => {
    const type = "limitations";
    const validTypes = ["medical", "ethical", "limitations", "warning"];
    
    expect(validTypes).toContain(type);
  });

  it("should display medical disclaimer content", () => {
    const content = "PneumoScan Pro is an AI-assisted analysis tool designed for educational and research purposes only.";
    
    expect(content).toContain("AI-assisted");
    expect(content).toContain("educational");
    expect(content).toContain("research");
  });

  it("should display model limitations notice", () => {
    const limitations = [
      "95% accuracy on validation dataset",
      "Not suitable for all image qualities",
      "May produce false positives/negatives",
      "Requires radiologist confirmation",
    ];
    
    expect(limitations).toHaveLength(4);
    expect(limitations[0]).toContain("95%");
  });

  it("should display ethical disclaimer", () => {
    const ethical = [
      "Model trained on diverse datasets",
      "Potential biases may exist",
      "Data privacy is protected",
      "Transparent decision-making",
    ];
    
    expect(ethical).toHaveLength(4);
    expect(ethical[1]).toContain("biases");
  });

  it("should include warning icon for medical type", () => {
    const type = "medical";
    const hasIcon = true; // showIcon prop default
    
    expect(type).toBe("medical");
    expect(hasIcon).toBe(true);
  });

  it("should have appropriate styling for each type", () => {
    const styles = {
      medical: "bg-amber-50 border-amber-200",
      ethical: "bg-blue-50 border-blue-200",
      limitations: "bg-orange-50 border-orange-200",
      warning: "bg-red-50 border-red-200",
    };
    
    expect(styles.medical).toContain("amber");
    expect(styles.ethical).toContain("blue");
    expect(styles.limitations).toContain("orange");
    expect(styles.warning).toContain("red");
  });

  it("should validate disclaimer text presence", () => {
    const disclaimerText = "Always consult with a qualified healthcare professional";
    
    expect(disclaimerText).toBeTruthy();
    expect(disclaimerText.length).toBeGreaterThan(0);
  });
});
