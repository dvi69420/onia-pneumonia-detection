import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MetricsGrid, MetricBadge } from "@/components/MetricBadge";
import { DisclaimerBanner } from "@/components/DisclaimerBanner";
import {
  ArrowRight,
  BarChart3,
  Brain,
  CheckCircle2,
  Heart,
  Microscope,
  Shield,
  Stethoscope,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";

import { getLoginUrl } from "@/const";

export default function Home() {
  const { isAuthenticated } = useAuth();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      window.location.href = "/analysis";
    } else {
      window.location.href = getLoginUrl();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <header className="border-b border-border bg-white sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Microscope className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">PneumoScan Pro</h1>
          </div>
          <Button onClick={handleGetStarted} variant="default" size="sm">
            Start Analysis
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="container py-16 md:py-24 space-y-8">
          <div className="max-w-3xl space-y-6">
            <div className="inline-block px-4 py-2 bg-blue-100 rounded-full">
              <p className="text-sm font-semibold text-blue-700">
                AI-Powered Medical Imaging Analysis
              </p>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
              Early Pneumonia Detection from Chest X-Rays
            </h2>
            <p className="text-xl text-gray-600">
              PneumoScan Pro uses advanced AI to assist healthcare professionals in detecting pneumonia with high accuracy and transparency. Built for doctors, clinics, and rural healthcare providers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button onClick={handleGetStarted} size="lg" className="gap-2">
                Upload Your X-Ray <ArrowRight className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="lg">
                Learn More
              </Button>
            </div>
          </div>
        </section>

        {/* Problem Statement Section */}
        <section className="container py-16 space-y-8">
          <div className="text-center space-y-4 mb-12">
            <h3 className="text-3xl font-bold text-gray-900">The Challenge</h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Early pneumonia detection is critical but challenging, especially in resource-limited settings
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Challenge 1 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-red-100">
                <Heart className="h-6 w-6 text-red-600" />
              </div>
              <h4 className="text-lg font-semibold">High Mortality Rate</h4>
              <p className="text-gray-600 text-sm">
                Pneumonia remains a leading cause of death worldwide, with early detection being crucial for survival.
              </p>
            </Card>

            {/* Challenge 2 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-orange-100">
                <Users className="h-6 w-6 text-orange-600" />
              </div>
              <h4 className="text-lg font-semibold">Radiologist Shortage</h4>
              <p className="text-gray-600 text-sm">
                Many regions lack sufficient radiologists, leading to delayed diagnoses and patient outcomes.
              </p>
            </Card>

            {/* Challenge 3 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-yellow-100">
                <TrendingUp className="h-6 w-6 text-yellow-600" />
              </div>
              <h4 className="text-lg font-semibold">Diagnostic Variability</h4>
              <p className="text-gray-600 text-sm">
                Manual interpretation varies between radiologists, leading to inconsistent diagnoses.
              </p>
            </Card>
          </div>
        </section>

        {/* Target Users Section */}
        <section className="container py-16 space-y-8">
          <div className="text-center space-y-4 mb-12">
            <h3 className="text-3xl font-bold text-gray-900">Who We Serve</h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              PneumoScan Pro is designed for healthcare professionals at all levels
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Radiologists */}
            <Card className="p-6 space-y-4 border-2 border-blue-200 bg-blue-50">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
                <Stethoscope className="h-6 w-6 text-blue-600" />
              </div>
              <h4 className="text-lg font-semibold">Radiologists & Doctors</h4>
              <p className="text-gray-600 text-sm">
                Get a second opinion with AI-assisted analysis and Grad-CAM visualizations for better decision-making.
              </p>
            </Card>

            {/* Clinics */}
            <Card className="p-6 space-y-4 border-2 border-green-200 bg-green-50">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100">
                <Building2 className="h-6 w-6 text-green-600" />
              </div>
              <h4 className="text-lg font-semibold">Clinics & Hospitals</h4>
              <p className="text-gray-600 text-sm">
                Streamline workflows with rapid pneumonia screening and consistent diagnostic support.
              </p>
            </Card>

            {/* Rural Healthcare */}
            <Card className="p-6 space-y-4 border-2 border-purple-200 bg-purple-50">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100">
                <Globe className="h-6 w-6 text-purple-600" />
              </div>
              <h4 className="text-lg font-semibold">Rural Healthcare</h4>
              <p className="text-gray-600 text-sm">
                Enable remote areas to access expert-level diagnostic support without traveling for specialist consultation.
              </p>
            </Card>
          </div>
        </section>

        {/* Impact Section */}
        <section className="container py-16 space-y-8">
          <div className="text-center space-y-4 mb-12">
            <h3 className="text-3xl font-bold text-gray-900">The Impact</h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Real numbers showing how AI-assisted diagnosis makes a difference
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <MetricBadge
              label="Detection Accuracy"
              value="95%"
              description="Validation accuracy on test datasets"
              icon={<BarChart3 className="h-5 w-5" />}
            />
            <MetricBadge
              label="AUC-ROC Score"
              value="0.98"
              description="Model discrimination ability"
              icon={<Brain className="h-5 w-5" />}
            />
            <MetricBadge
              label="Processing Time"
              value="<2s"
              description="Average inference time per scan"
              icon={<Zap className="h-5 w-5" />}
            />
            <MetricBadge
              label="Datasets Used"
              value="2"
              description="Guangzhou + RSNA"
              icon={<Microscope className="h-5 w-5" />}
            />
          </div>
        </section>

        {/* How It Works Section */}
        <section className="container py-16 space-y-8">
          <div className="text-center space-y-4 mb-12">
            <h3 className="text-3xl font-bold text-gray-900">How It Works</h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Understanding our AI model from data to diagnosis
            </p>
          </div>

          {/* Step-by-step process */}
          <div className="space-y-6">
            {/* Step 1: Dataset */}
            <Card className="p-6 md:p-8 space-y-4">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
                  <span className="font-bold text-blue-600">1</span>
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold mb-2">Training Data</h4>
                  <p className="text-gray-600 mb-4">
                    Our model is trained on two publicly available, well-established chest X-ray datasets:
                  </p>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>
                        <strong>Guangzhou Dataset:</strong> Comprehensive collection of pediatric chest X-rays with pneumonia annotations
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>
                        <strong>RSNA Dataset:</strong> Radiological Society of North America pneumonia detection challenge dataset
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* Step 2: Preprocessing */}
            <Card className="p-6 md:p-8 space-y-4">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
                  <span className="font-bold text-blue-600">2</span>
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold mb-2">Image Preprocessing</h4>
                  <p className="text-gray-600 mb-4">
                    Each uploaded X-ray undergoes standardized preprocessing to ensure consistency:
                  </p>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>Resizing:</strong> Images normalized to 224×224 pixels</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>Normalization:</strong> Pixel values scaled to 0-1 range</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>Format Support:</strong> JPEG, PNG, and DICOM formats accepted</span>
                    </li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* Step 3: Model Architecture */}
            <Card className="p-6 md:p-8 space-y-4">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
                  <span className="font-bold text-blue-600">3</span>
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold mb-2">AI Model Architecture</h4>
                  <p className="text-gray-600 mb-4">
                    We use a Convolutional Neural Network (CNN) based on EfficientNetB0:
                  </p>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>
                        <strong>Architecture:</strong> EfficientNetB0 - optimized for both accuracy and computational efficiency
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>
                        <strong>Why CNN:</strong> Excellent at capturing spatial patterns in medical images
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>
                        <strong>Interpretability:</strong> Grad-CAM visualization shows which regions influenced the prediction
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* Step 4: Evaluation */}
            <Card className="p-6 md:p-8 space-y-4">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
                  <span className="font-bold text-blue-600">4</span>
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold mb-2">Model Evaluation & Validation</h4>
                  <p className="text-gray-600 mb-4">
                    Rigorous testing ensures reliable performance:
                  </p>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>Accuracy:</strong> 95% on validation dataset</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>AUC-ROC:</strong> 0.98 - excellent discrimination between classes</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>Cross-validation:</strong> Multiple train-test splits to ensure robustness</span>
                    </li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Features Section */}
        <section className="container py-16 space-y-8">
          <div className="text-center space-y-4 mb-12">
            <h3 className="text-3xl font-bold text-gray-900">Key Features</h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Built for clinical accuracy and ease of use
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Feature 1 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
                <Brain className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold">AI-Powered Analysis</h3>
              <p className="text-muted-foreground">
                Advanced CNN model with 95% accuracy for pneumonia detection from chest X-rays.
              </p>
            </Card>

            {/* Feature 2 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100">
                <Zap className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold">Grad-CAM Visualization</h3>
              <p className="text-muted-foreground">
                See which regions of the X-ray influenced the model's prediction for transparency.
              </p>
            </Card>

            {/* Feature 3 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-100">
                <CheckCircle2 className="h-6 w-6 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold">Confidence Scores</h3>
              <p className="text-muted-foreground">
                Get detailed probability breakdowns for both NORMAL and PNEUMONIA classifications.
              </p>
            </Card>

            {/* Feature 4 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-cyan-100">
                <Shield className="h-6 w-6 text-cyan-600" />
              </div>
              <h3 className="text-lg font-semibold">HIPAA Compliant</h3>
              <p className="text-muted-foreground">
                Enterprise-grade security with encrypted storage and secure data handling for patient privacy.
              </p>
            </Card>

            {/* Feature 5 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-rose-100">
                <CheckCircle2 className="h-6 w-6 text-rose-600" />
              </div>
              <h3 className="text-lg font-semibold">Multiple Formats</h3>
              <p className="text-muted-foreground">
                Support for JPEG, PNG, and DICOM formats with automatic preprocessing and optimization.
              </p>
            </Card>

            {/* Feature 6 */}
            <Card className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-orange-100">
                <BarChart3 className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-lg font-semibold">Scan History</h3>
              <p className="text-muted-foreground">
                Complete analysis history with timestamps, predictions, and confidence scores for tracking.
              </p>
            </Card>
          </div>
        </section>

        {/* Medical Disclaimer Section */}
        <section className="container py-16">
          <DisclaimerBanner
            type="medical"
            title="Medical Disclaimer"
            content={
              <p>
                PneumoScan Pro is an AI-powered analysis tool designed for educational and research purposes only. It is <strong>NOT</strong> a substitute for professional medical diagnosis. Results should always be reviewed by qualified healthcare professionals. Always consult with a licensed radiologist or physician for clinical diagnosis and treatment decisions.
              </p>
            }
          />
        </section>

        {/* CTA Section */}
        <section className="container py-16">
          <div className="mx-auto max-w-2xl rounded-2xl bg-gradient-to-r from-blue-600 to-blue-700 p-8 md:p-12 text-center text-white space-y-6">
            <h2 className="text-3xl font-bold md:text-4xl">Ready to Get Started?</h2>
            <p className="text-lg text-blue-100">
              Upload your chest X-ray and get instant AI-powered pneumonia detection analysis.
            </p>
            <Button
              onClick={handleGetStarted}
              size="lg"
              variant="secondary"
              className="gap-2"
            >
              Start Analysis Now <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-slate-50 py-8 mt-24">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-3 mb-8">
            <div className="space-y-2">
              <h4 className="font-semibold">PneumoScan Pro</h4>
              <p className="text-sm text-muted-foreground">
                Advanced AI-powered pneumonia detection for medical imaging analysis.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Legal</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Medical Disclaimer
                  </a>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Support</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
            <p>&copy; 2026 PneumoScan Pro. All rights reserved.</p>
            <p>Built with advanced AI technology for medical imaging analysis.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Icon imports for missing icons
function Building2(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  );
}

function Globe(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a14.5 14.5 0 0 1 0 20 14.5 14.5 0 0 1 0-20" />
      <path d="M2 12h20" />
    </svg>
  );
}
