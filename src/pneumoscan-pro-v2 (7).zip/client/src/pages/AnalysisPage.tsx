import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ResultCard } from "@/components/ResultCard";
import { ConfidenceBar } from "@/components/ConfidenceBar";
import { HeatmapViewer } from "@/components/HeatmapViewer";
import { DisclaimerBanner, ModelLimitationsNotice, EthicalDisclaimerNotice } from "@/components/DisclaimerBanner";
import { MetricsGrid, MetricBadge } from "@/components/MetricBadge";
import { LoadingSpinner, ProgressSteps } from "@/components/LoadingSpinner";
import { SampleImages } from "@/components/SampleImages";
import {
  AlertCircle,
  ArrowLeft,
  BarChart3,
  Download,
  Microscope,
  Plus,
  Share2,
  Sparkles,
  Zap,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

interface AnalysisResult {
  scanId: string;
  prediction: "NORMAL" | "PNEUMONIA";
  confidence: number;
  normalProbability: number;
  pneumoniaProbability: number;
  processingTimeMs: number;
  imageUrl: string;
  heatmapUrl?: string;
  modelVersion: string;
  timestamp: Date;
}

export default function AnalysisPage() {
  const { isAuthenticated } = useAuth();
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // Redirect if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-50 to-white">
        <Card className="p-8 max-w-md text-center space-y-4">
          <AlertCircle className="h-12 w-12 text-amber-600 mx-auto" />
          <h2 className="text-2xl font-bold">Authentication Required</h2>
          <p className="text-gray-600">
            Please sign in to access the analysis tool.
          </p>
          <Button
            onClick={() => {
              window.location.href = getLoginUrl();
            }}
            className="w-full"
          >
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedImage(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setPreviewUrl(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!uploadedImage) return;

    setLoading(true);
    // Simulate analysis with progress
    setTimeout(() => {
      setResult({
        scanId: `SCAN-${Date.now()}`,
        prediction: Math.random() > 0.5 ? "NORMAL" : "PNEUMONIA",
        confidence: Math.random() * 20 + 80,
        normalProbability: Math.random() * 30,
        pneumoniaProbability: Math.random() * 30 + 70,
        processingTimeMs: Math.floor(Math.random() * 1000) + 500,
        imageUrl: previewUrl || "",
        heatmapUrl: previewUrl || "",
        modelVersion: "1.0-finetuned",
        timestamp: new Date(),
      });
      setLoading(false);
    }, 2000);
  };

  const handleSampleImageSelect = (imageUrl: string, imageName: string) => {
    setPreviewUrl(imageUrl);
    // Create a mock file for the sample image
    const mockFile = new File([imageName], imageName, { type: "image/jpeg" });
    setUploadedImage(mockFile);
  };

  const handleDemoMode = () => {
    setLoading(true);

    // Simulate demo analysis with predetermined result
    setTimeout(() => {
      setResult({
        scanId: `DEMO-${Date.now()}`,
        prediction: "PNEUMONIA",
        confidence: 94.2,
        normalProbability: 5.8,
        pneumoniaProbability: 94.2,
        processingTimeMs: 1250,
        imageUrl: "https://via.placeholder.com/400x400?text=Sample+X-Ray",
        heatmapUrl: "https://via.placeholder.com/400x400?text=Grad-CAM+Heatmap",
        modelVersion: "1.0-finetuned",
        timestamp: new Date(),
      });
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="border-b border-border bg-white sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              window.location.href = "/";
            }}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-xl font-bold text-gray-900">X-Ray Analysis</h1>
          <div className="w-20" />
        </div>
      </header>

      <main className="container py-8 space-y-8">
        {loading ? (
          // Loading Section
          <div className="max-w-2xl mx-auto space-y-8 py-12">
            <div className="text-center space-y-6">
              <LoadingSpinner
                message="Analyzing your chest X-ray..."
                size="lg"
              />
              <div className="space-y-4">
                <ProgressSteps
                  steps={[
                    { label: "Preprocessing image", status: "completed" },
                    { label: "Running AI model", status: "in-progress" },
                    { label: "Generating Grad-CAM", status: "pending" },
                  ]}
                />
              </div>
              <p className="text-sm text-gray-600">
                This typically takes 1-3 seconds
              </p>
            </div>
          </div>
        ) : !result ? (
          // Upload Section
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Instructions */}
            <Card className="p-6 md:p-8 bg-blue-50 border-blue-200 space-y-4">
              <div className="flex gap-3">
                <Microscope className="h-6 w-6 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-lg font-semibold text-blue-900 mb-2">
                    How to Use
                  </h2>
                  <ol className="space-y-2 text-sm text-blue-800">
                    <li className="flex gap-2">
                      <span className="font-semibold">1.</span>
                      <span>Upload a chest X-ray image (JPEG, PNG, or DICOM)</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-semibold">2.</span>
                      <span>Our AI model will analyze the image</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-semibold">3.</span>
                      <span>Review the prediction with confidence scores and Grad-CAM visualization</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-semibold">4.</span>
                      <span>Always consult with a qualified healthcare professional</span>
                    </li>
                  </ol>
                </div>
              </div>
            </Card>

            {/* Upload Area */}
            <Card className="p-8 border-2 border-dashed border-gray-300 hover:border-blue-400 transition-colors">
              <div className="space-y-4 text-center">
                {previewUrl ? (
                  <div className="space-y-4 animate-in fade-in-50 duration-300">
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="max-h-64 mx-auto rounded-lg shadow-md"
                    />
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        {uploadedImage?.name}
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setUploadedImage(null);
                          setPreviewUrl(null);
                        }}
                      >
                        Change Image
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-center">
                      <div className="h-16 w-16 rounded-full bg-blue-100 flex items-center justify-center animate-pulse">
                        <Plus className="h-8 w-8 text-blue-600" />
                      </div>
                    </div>
                    <div>
                      <p className="text-lg font-semibold text-gray-900">
                        Upload Chest X-Ray
                      </p>
                      <p className="text-sm text-gray-600">
                        Drag and drop or click to select
                      </p>
                    </div>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,.dcm"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          document.getElementById("image-upload")?.click()
                        }
                      >
                        Select File
                      </Button>
                    </label>
                  </>
                )}
              </div>
            </Card>

            {/* Sample Images */}
            <SampleImages onSelectImage={handleSampleImageSelect} />

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={handleAnalyze}
                disabled={!uploadedImage || loading}
                size="lg"
                className="gap-2 flex-1"
              >
                <Sparkles className="h-4 w-4" />
                Analyze Image
              </Button>
              <Button
                onClick={handleDemoMode}
                variant="outline"
                size="lg"
                disabled={loading}
                className="gap-2"
              >
                <Zap className="h-4 w-4" />
                Demo Mode
              </Button>
            </div>

            {/* Medical Disclaimer */}
            <DisclaimerBanner
              type="medical"
              title="Important Notice"
              content={
                <p>
                  PneumoScan Pro is an AI-assisted analysis tool designed for <strong>educational and research purposes only</strong>. It is <strong>NOT</strong> a substitute for professional medical diagnosis. Always consult with a qualified healthcare professional for clinical decisions.
                </p>
              }
            />
          </div>
        ) : (
          // Results Section
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in-50 duration-500">
            {/* Medical Disclaimer - Results */}
            <DisclaimerBanner
              type="medical"
              title="Important Notice"
              content={
                <p>
                  These results are AI-assisted analysis only. <strong>Always consult with a qualified healthcare professional</strong> before making any clinical decisions.
                </p>
              }
            />

            {/* Main Result Card */}
            <ResultCard
              prediction={result.prediction}
              confidence={result.confidence}
              normalProbability={result.normalProbability}
              pneumoniaProbability={result.pneumoniaProbability}
            />

            {/* Confidence Explanation */}
            <Card className="p-6 space-y-4 bg-slate-50">
              <h3 className="text-lg font-semibold">Understanding Confidence</h3>
              <div className="space-y-4">
                <ConfidenceBar
                  confidence={result.confidence}
                  label="Overall Model Confidence"
                />
                <p className="text-sm text-gray-600">
                  The confidence score represents how certain the model is about its prediction. A score of 80-100% indicates high confidence, while lower scores suggest the model is less certain. However, confidence alone does not guarantee accuracy—always consider clinical context.
                </p>
              </div>
            </Card>

            {/* Heatmap Visualization */}
            {result.heatmapUrl && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Visual Explanation</h3>
                <HeatmapViewer
                  heatmapUrl={result.heatmapUrl}
                  originalImageUrl={result.imageUrl}
                  prediction={result.prediction}
                />
              </div>
            )}

            {/* Model Limitations */}
            <ModelLimitationsNotice />

            {/* Ethical Disclaimer */}
            <EthicalDisclaimerNotice />

            {/* Metadata */}
            <Card className="p-6 bg-slate-50 space-y-4">
              <h3 className="font-semibold">Analysis Details</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Scan ID</p>
                  <p className="font-semibold font-mono text-xs">{result.scanId}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Processing Time</p>
                  <p className="font-semibold">{result.processingTimeMs}ms</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Timestamp</p>
                  <p className="font-semibold text-xs">
                    {result.timestamp.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Model Version</p>
                  <p className="font-semibold text-xs">{result.modelVersion}</p>
                </div>
              </div>
            </Card>

            {/* Model Performance Metrics */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Model Performance</h3>
              <MetricsGrid
                metrics={[
                  {
                    label: "Validation Accuracy",
                    value: "95%",
                    description: "On test dataset",
                    icon: <BarChart3 className="h-5 w-5" />,
                  },
                  {
                    label: "AUC-ROC Score",
                    value: "0.98",
                    description: "Model discrimination",
                    icon: <BarChart3 className="h-5 w-5" />,
                  },
                  {
                    label: "Training Dataset",
                    value: "2",
                    description: "Guangzhou + RSNA",
                    icon: <Microscope className="h-5 w-5" />,
                  },
                  {
                    label: "Architecture",
                    value: "CNN",
                    description: "EfficientNetB0",
                    icon: <Zap className="h-5 w-5" />,
                  },
                ]}
              />
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={() => {
                  setResult(null);
                  setUploadedImage(null);
                  setPreviewUrl(null);
                }}
                variant="outline"
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                Analyze Another
              </Button>
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Download Report
              </Button>
              <Button variant="outline" className="gap-2">
                <Share2 className="h-4 w-4" />
                Share Results
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
