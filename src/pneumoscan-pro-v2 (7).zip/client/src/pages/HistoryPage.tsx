import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  AlertCircle,
  ArrowLeft,
  BarChart3,
  CheckCircle,
  Download,
  Eye,
  Filter,
  TrendingUp,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

interface ScanRecord {
  id: string;
  timestamp: Date;
  prediction: "NORMAL" | "PNEUMONIA";
  confidence: number;
  imageUrl: string;
  modelVersion: string;
}

// Mock data for demonstration
const mockScans: ScanRecord[] = [
  {
    id: "SCAN-001",
    timestamp: new Date(Date.now() - 86400000),
    prediction: "NORMAL",
    confidence: 92.5,
    imageUrl: "https://via.placeholder.com/100x100?text=X-Ray+1",
    modelVersion: "1.0-finetuned",
  },
  {
    id: "SCAN-002",
    timestamp: new Date(Date.now() - 172800000),
    prediction: "PNEUMONIA",
    confidence: 88.3,
    imageUrl: "https://via.placeholder.com/100x100?text=X-Ray+2",
    modelVersion: "1.0-finetuned",
  },
  {
    id: "SCAN-003",
    timestamp: new Date(Date.now() - 259200000),
    prediction: "NORMAL",
    confidence: 95.1,
    imageUrl: "https://via.placeholder.com/100x100?text=X-Ray+3",
    modelVersion: "1.0-finetuned",
  },
  {
    id: "SCAN-004",
    timestamp: new Date(Date.now() - 345600000),
    prediction: "PNEUMONIA",
    confidence: 91.7,
    imageUrl: "https://via.placeholder.com/100x100?text=X-Ray+4",
    modelVersion: "1.0-finetuned",
  },
  {
    id: "SCAN-005",
    timestamp: new Date(Date.now() - 432000000),
    prediction: "NORMAL",
    confidence: 89.4,
    imageUrl: "https://via.placeholder.com/100x100?text=X-Ray+5",
    modelVersion: "1.0-finetuned",
  },
];

export default function HistoryPage() {
  const { isAuthenticated } = useAuth();
  const [scans] = useState<ScanRecord[]>(mockScans);
  const [selectedScan, setSelectedScan] = useState<ScanRecord | null>(null);
  const [filterPrediction, setFilterPrediction] = useState<"ALL" | "NORMAL" | "PNEUMONIA">("ALL");

  // Redirect if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-50 to-white">
        <Card className="p-8 max-w-md text-center space-y-4">
          <AlertCircle className="h-12 w-12 text-amber-600 mx-auto" />
          <h2 className="text-2xl font-bold">Authentication Required</h2>
          <p className="text-gray-600">
            Please sign in to view your scan history.
          </p>
          <Button
            onClick={() => {
              window.location.href = getLoginUrl();
            }}
            className="w-full"
          >
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  // Calculate statistics
  const totalScans = scans.length;
  const normalCount = scans.filter((s) => s.prediction === "NORMAL").length;
  const pneumoniaCount = scans.filter((s) => s.prediction === "PNEUMONIA").length;
  const averageConfidence =
    scans.reduce((sum, s) => sum + s.confidence, 0) / scans.length;

  // Filter scans
  const filteredScans =
    filterPrediction === "ALL"
      ? scans
      : scans.filter((s) => s.prediction === filterPrediction);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="border-b border-border bg-white sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              window.location.href = "/";
            }}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-xl font-bold text-gray-900">Scan History</h1>
          <div className="w-20" />
        </div>
      </header>

      <main className="container py-8 space-y-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="p-6 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-muted-foreground">
                Total Scans
              </p>
              <BarChart3 className="h-5 w-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold">{totalScans}</p>
          </Card>

          <Card className="p-6 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-muted-foreground">
                Normal Results
              </p>
              <CheckCircle className="h-5 w-5 text-emerald-600" />
            </div>
            <p className="text-3xl font-bold">{normalCount}</p>
            <p className="text-xs text-gray-600">
              {((normalCount / totalScans) * 100).toFixed(1)}%
            </p>
          </Card>

          <Card className="p-6 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-muted-foreground">
                Pneumonia Detected
              </p>
              <AlertCircle className="h-5 w-5 text-red-600" />
            </div>
            <p className="text-3xl font-bold">{pneumoniaCount}</p>
            <p className="text-xs text-gray-600">
              {((pneumoniaCount / totalScans) * 100).toFixed(1)}%
            </p>
          </Card>

          <Card className="p-6 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-muted-foreground">
                Avg Confidence
              </p>
              <TrendingUp className="h-5 w-5 text-purple-600" />
            </div>
            <p className="text-3xl font-bold">{averageConfidence.toFixed(1)}%</p>
          </Card>
        </div>

        {/* Filters */}
        <Card className="p-4 space-y-3">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="h-5 w-5 text-gray-600" />
            <p className="font-semibold">Filter Results</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {(["ALL", "NORMAL", "PNEUMONIA"] as const).map((filter) => (
              <Button
                key={filter}
                variant={filterPrediction === filter ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterPrediction(filter)}
              >
                {filter}
              </Button>
            ))}
          </div>
        </Card>

        {/* Scan List */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Recent Scans</h2>
          <div className="space-y-3">
            {filteredScans.length > 0 ? (
              filteredScans.map((scan) => (
                <Card
                  key={scan.id}
                  className="p-4 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => setSelectedScan(scan)}
                >
                  <div className="flex items-center gap-4">
                    {/* Image Thumbnail */}
                    <img
                      src={scan.imageUrl}
                      alt={scan.id}
                      className="h-20 w-20 rounded-lg object-cover bg-gray-200"
                    />

                    {/* Scan Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-sm">{scan.id}</p>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            scan.prediction === "NORMAL"
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-red-100 text-red-700"
                          }`}
                        >
                          {scan.prediction}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600">
                        {scan.timestamp.toLocaleString()}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Confidence: {scan.confidence.toFixed(1)}%
                      </p>
                    </div>

                    {/* Action Button */}
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedScan(scan);
                      }}
                    >
                      <Eye className="h-4 w-4" />
                      View
                    </Button>
                  </div>
                </Card>
              ))
            ) : (
              <Card className="p-8 text-center">
                <p className="text-gray-600">No scans found with the selected filter.</p>
              </Card>
            )}
          </div>
        </div>

        {/* Detail Modal */}
        {selectedScan && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-2xl w-full max-h-96 overflow-y-auto space-y-4 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold">Scan Details</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedScan(null)}
                >
                  ✕
                </Button>
              </div>

              {/* Image */}
              <img
                src={selectedScan.imageUrl}
                alt={selectedScan.id}
                className="w-full h-64 object-cover rounded-lg bg-gray-200"
              />

              {/* Details Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Scan ID</p>
                  <p className="font-semibold">{selectedScan.id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Prediction</p>
                  <p className="font-semibold">{selectedScan.prediction}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Confidence</p>
                  <p className="font-semibold">{selectedScan.confidence.toFixed(1)}%</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Date & Time</p>
                  <p className="font-semibold text-sm">
                    {selectedScan.timestamp.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Model Version</p>
                  <p className="font-semibold text-sm">{selectedScan.modelVersion}</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-4">
                <Button variant="outline" className="gap-2 flex-1">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedScan(null)}
                  className="flex-1"
                >
                  Close
                </Button>
              </div>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
